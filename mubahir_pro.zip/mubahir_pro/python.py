from flask import Flask, render_template, request, send_file, jsonify
from flask_cors import CORS
from PIL import Image
import io, os
from Crypto.Cipher import AES
from Crypto.Protocol.KDF import PBKDF2  
from Crypto.Random import get_random_bytes


app = Flask(__name__)
CORS(app)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['SECRET_KEY'] = 'your-secret-key-here'
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
ALLOWED_EXTENSIONS = {'png', 'bmp'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def derive_key(password: str, salt: bytes) -> bytes:
    return PBKDF2(password, salt, dkLen=32, count=100000)

def encrypt_message(message: str, password: str) -> tuple:
    salt = get_random_bytes(16)
    key = derive_key(password, salt)
    cipher = AES.new(key, AES.MODE_GCM)
    ciphertext, tag = cipher.encrypt_and_digest(message.encode('utf-8'))
    return salt, cipher.nonce, tag, ciphertext

def decrypt_message(salt: bytes, nonce: bytes, tag: bytes, ciphertext: bytes, password: str) -> str:
    key = derive_key(password, salt)
    cipher = AES.new(key, AES.MODE_GCM, nonce=nonce)
    plaintext = cipher.decrypt_and_verify(ciphertext, tag)
    return plaintext.decode('utf-8')

def hide_data_in_image(image_path: str, encrypted_data: bytes) -> Image:
    img = Image.open(image_path).convert('RGB')
    pixels = list(img.getdata())
    width, height = img.size
    payload = len(encrypted_data).to_bytes(4, 'big') + encrypted_data
    payload_bits = ''.join(format(byte, '08b') for byte in payload)
    max_bits = width * height * 3
    if len(payload_bits) > max_bits:
        raise ValueError("Message too large for this image")
    new_pixels, bit_idx = [], 0
    for pixel in pixels:
        r, g, b = pixel
        if bit_idx < len(payload_bits):
            r = (r & 0xFE) | int(payload_bits[bit_idx])
            bit_idx += 1
        if bit_idx < len(payload_bits):
            g = (g & 0xFE) | int(payload_bits[bit_idx])
            bit_idx += 1
        if bit_idx < len(payload_bits):
            b = (b & 0xFE) | int(payload_bits[bit_idx])
            bit_idx += 1
        new_pixels.append((r, g, b))
    stego_img = Image.new('RGB', (width, height))
    stego_img.putdata(new_pixels)
    return stego_img

def extract_data_from_image(image_path: str) -> bytes:
    img = Image.open(image_path).convert('RGB')
    pixels = list(img.getdata())
    bits = []
    for pixel in pixels:
        r, g, b = pixel
        bits.append(str(r & 1))
        bits.append(str(g & 1))
        bits.append(str(b & 1))
    bit_string = ''.join(bits)
    length = int(bit_string[:32], 2)
    data_bits = bit_string[32:32 + length * 8]
    encrypted_data = bytearray()
    for i in range(0, len(data_bits), 8):
        encrypted_data.append(int(data_bits[i:i+8], 2))
    return bytes(encrypted_data)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/hide', methods=['POST'])
def hide_message():
    try:
        if 'image' not in request.files:
            return jsonify({'error': 'No image file'}), 400
        file = request.files['image']
        message = request.form.get('message', '')
        password = request.form.get('password', '')
        if not message or not password:
            return jsonify({'error': 'Message and password required'}), 400
        if not allowed_file(file.filename):
            return jsonify({'error': 'Only PNG/BMP supported'}), 400
        temp_path = os.path.join(app.config['UPLOAD_FOLDER'], 'temp_input.png')
        file.save(temp_path)
        salt, nonce, tag, ciphertext = encrypt_message(message, password)
        encrypted_data = salt + nonce + tag + ciphertext
        stego_img = hide_data_in_image(temp_path, encrypted_data)
        img_io = io.BytesIO()
        stego_img.save(img_io, 'PNG')
        img_io.seek(0)
        os.remove(temp_path)
        return send_file(img_io, mimetype='image/png', as_attachment=True, download_name='stego_image.png')
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/reveal', methods=['POST'])
def reveal_message():
    try:
        if 'image' not in request.files:
            return jsonify({'error': 'No image file'}), 400
        file = request.files['image']
        password = request.form.get('password', '')
        if not password:
            return jsonify({'error': 'Password required'}), 400
        temp_path = os.path.join(app.config['UPLOAD_FOLDER'], 'temp_extract.png')
        file.save(temp_path)
        encrypted_data = extract_data_from_image(temp_path)
        salt = encrypted_data[:16]
        nonce = encrypted_data[16:32]
        tag = encrypted_data[32:48]
        ciphertext = encrypted_data[48:]
        message = decrypt_message(salt, nonce, tag, ciphertext, password)
        os.remove(temp_path)
        return jsonify({'message': message}), 200
    except Exception as e:
        return jsonify({'error': f'Failed to reveal: {str(e)}'}), 400

@app.route('/api/capacity', methods=['POST'])
def check_capacity():
    try:
        if 'image' not in request.files:
            return jsonify({'error': 'No image file'}), 400
        file = request.files['image']
        message = request.form.get('message', '')
        temp_path = os.path.join(app.config['UPLOAD_FOLDER'], 'temp_check.png')
        file.save(temp_path)
        img = Image.open(temp_path)
        width, height = img.size
        max_bits = width * height * 3
        max_bytes = (max_bits - 32) // 8
        message_bytes = len(message.encode('utf-8'))
        encrypted_size = message_bytes + 48
        os.remove(temp_path)
        return jsonify({
            'max_bytes': max_bytes,
            'message_bytes': encrypted_size,
            'can_fit': encrypted_size <= max_bytes,
            'percentage': (encrypted_size / max_bytes) * 100
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 400

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5001)

